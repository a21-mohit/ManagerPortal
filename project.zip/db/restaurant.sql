-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 04, 2018 at 09:42 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `msalary` int(11) DEFAULT NULL,
  `hire_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `emp_name`, `password`, `msalary`, `hire_date`, `end_date`) VALUES
(1001, 'Waiter1', 'abc123', 10000, '2018-01-01', NULL),
(1002, 'Waiter2', 'def123', 10000, '2018-01-01', NULL),
(1003, 'Waiter3', 'ghi123', 10000, '2018-01-01', NULL),
(1004, 'Waiter4', 'jkl123', 10000, '2018-01-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `category` varchar(32) NOT NULL,
  `mrp` int(11) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`item_id`, `item_name`, `category`, `mrp`) VALUES
(1, 'Fruit Punch', 'Mocktails', 75),
(2, 'Golden Gate', 'Mocktails', 75),
(3, 'Hawaian Colada', 'Mocktails', 75),
(4, 'Thunderstorm', 'Mocktails', 75),
(5, 'Midnight Beauty', 'Mocktails', 75),
(6, 'Green Temptation', 'Mocktails', 75),
(7, 'Vegetable Cheese Burger', 'Burgers', 60),
(8, 'Vegetable Burger', 'Burgers', 48),
(9, 'Vegetable Cutlet', 'Burgers', 40),
(10, 'Sweet Corn Vegetable', 'Chinese', 90),
(11, 'Sweet Manchow Soup', 'Chinese', 90),
(12, 'Cream of Tomato', 'Chinese', 90),
(13, 'Crispy Vegetables', 'Chinese', 190),
(14, 'Dry Chilly Potatoes', 'Chinese', 155),
(15, 'Chinese Bhel', 'Chinese', 165),
(16, 'French Fries', 'Chinese', 60),
(17, 'Vegetable Chowmein', 'Chinese', 165),
(18, 'Vegetable Fried Rice', 'Chinese', 190),
(19, 'Vegetable Manchurian', 'Chinese', 190),
(20, 'Vegetable Chopsucy', 'Chinese', 190),
(21, 'Chilli Paneer', 'Chinese', 230),
(22, 'Plain Green Salad Sandwich', 'Sandwiches', 60),
(23, 'Grilled Vegetable Sandwich', 'Sandwiches', 70),
(24, 'Bombay Masala Grilled Sandwich', 'Sandwiches', 80),
(25, 'Grilled Thousand Island Sandwich', 'Sandwiches', 80),
(26, 'Grilled Cheese & Vegetable Sandwich', 'Sandwiches', 80),
(27, 'Plain Cheese', 'Pizzas', 165),
(28, 'Tomato Cheese', 'Pizzas', 170),
(29, 'Exotic Vegie Delite', 'Pizzas', 190),
(30, 'Custom Topping', 'Pizzas', 190),
(31, 'Family Pizza', 'Pizzas', 340),
(32, 'Masala Dosa', 'South Indian', 90),
(33, 'Plain Dosa', 'South Indian', 80),
(34, 'Rawa Masala Dosa', 'South Indian', 100),
(35, 'Rawa Plain Dosa', 'South Indian', 90),
(36, 'Paper Masala Dosa', 'South Indian', 100),
(37, 'Paper Plain Dosa', 'South Indian', 90),
(38, 'Idli Sambar', 'South Indian', 68),
(39, 'Uttapam', 'South Indian', 100),
(40, 'Sambar Wada', 'South Indian', 70),
(41, 'Sambar Samosa', 'South Indian', 50),
(42, 'Upma', 'South Indian', 65),
(43, 'Lucknawi Aaloo Masala Chat', 'Chaat', 55),
(44, 'Raj Kachori', 'Chaat', 70),
(45, 'Dahi Papdi Chat', 'Chaat', 60),
(46, 'LDahi Wada', 'Chaat', 60),
(47, 'Panipuri', 'Chaat', 35),
(48, 'Mumbaiya Bhel', 'Chaat', 50),
(49, 'Dahi Samosa', 'Chaat', 50),
(50, 'Grilled Mix Vegetable Sizzler', 'Sizzlers', 280),
(51, 'Steak Paneer Sizzler', 'Sizzlers', 285),
(52, 'Exotic Vegetable Pasta', 'Italian Pasta', 210),
(53, 'Macaroni Hot Pot', 'Italian Pasta', 210),
(54, 'Lasagne Napolitian', 'Italian Pasta', 210),
(55, 'Spaghetti Florentine', 'Italian Pasta', 210),
(56, 'Choley Kulchey', 'Specialities', 100),
(57, 'Choley Bhaturey', 'Specialities', 100),
(58, 'Mumbai Buttery Pav-Bhaji', 'Specialities', 95),
(59, 'Paneer Kathi Roll', 'Specialities', 120),
(60, 'Paneer Butter Masala', 'Indian', 240),
(61, 'Paneer Taka-Tak', 'Indian', 250),
(62, 'Spaciality Paneer of the Day', 'Indian', 250),
(63, 'Today\'s Special Vegetable', 'Indian', 210),
(64, 'Mix Vegetable', 'Indian', 200),
(65, 'Dal Makhani', 'Indian', 185),
(66, 'Yellow Dal', 'Indian', 145),
(67, 'Special Matka Biryani', 'Indian', 210),
(68, 'Pulav of the Day', 'Indian', 150),
(69, 'Steam Rice', 'Indian', 135),
(70, 'Tandoori Roti', 'Indian', 20),
(71, 'Butter Tandoori Roti', 'Indian', 25),
(72, 'Lachha Paratha', 'Indian', 30),
(73, 'Naan', 'Indian', 30),
(74, 'Butter Naan', 'Indian', 35),
(75, 'Roasted Papad', 'Indian', 20),
(76, 'Masala Papad', 'Indian', 30),
(77, 'Sampoorna Thaali', 'Thaali', 165),
(78, 'Packed Sampoorna Thaali', 'Thaali', 180),
(79, 'Nawabi Deluxe Platter', 'Thaali', 220),
(80, 'Packed Nawabi Deluxe Platter', 'Thaali', 235);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
