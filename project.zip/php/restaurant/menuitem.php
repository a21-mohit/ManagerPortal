<?php
require "conn.php";
if(isset($_POST["category"])){
	$category = $_POST["category"];
	$mysql_qry = "select distinct item_name from menu where category like '$category'";
	$result = mysqli_query($conn,$mysql_qry);
	$menuarray=array();
	while($row = mysqli_fetch_assoc($result)){
		foreach($row as $cname => $cvalue){
			array_push($menuarray,"$cvalue");
		}
	}
	$obj = (object) [
		$category => $menuarray
	];
	print json_encode($obj);
}
else {
	$resultArr=array();
	$sql = "select distinct category from menu order by category";
	$result = mysqli_query($conn,$sql);
	if ($result->num_rows > 0) {
		$resultArr = array('success' => true, 'total categories' => $result->num_rows);
		while($row = $result->fetch_assoc()) {
			$resultArr['categories'][$row['category']] = array();

			//Anwser table results
			$sql2 = "SELECT item_name FROM menu WHERE category='".$row['category']."'";
			$result2 = $conn->query($sql2);
			while($row2 = $result2->fetch_assoc()) {
				foreach($row2 as $cname => $cvalue){
					$resultArr['categories'][$row['category']][] = $cvalue;
				}
			}
		}
	}
	else {
		$resultArr = array('success' => false, 'total' => 0);
		echo "categories 0 results";
	}
	print json_encode($resultArr);   
}
?>