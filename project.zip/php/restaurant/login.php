<?php
require "conn.php";
if(isset($_POST["username"]) && isset($_POST["password"])){
	$user_name = $_POST["username"];
	$user_pass = $_POST["password"];
	$mysql_qry = "select * from employee where emp_id = $user_name and password like '$user_pass';";
	$result = mysqli_query($conn,$mysql_qry);
	if (mysqli_num_rows($result) == 1){
		echo "login success";
	}
	else{
		echo "login not success";
	}
}
?>