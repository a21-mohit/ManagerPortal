<?php
require "conn.php";
$mysql_qry = "select distinct category from menu order by category";
$result = mysqli_query($conn,$mysql_qry);
$categoryarray=array();
while($row = mysqli_fetch_assoc($result)){
    foreach($row as $cname => $cvalue){
        array_push($categoryarray,"$cvalue");
    }
}
$obj = (object) [
	'categories' => $categoryarray
];
echo json_encode($obj);
?>